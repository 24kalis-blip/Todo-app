// Add these helper functions if missing

function db_fetch_one($pdo, $table, $where) {
    $sql = "SELECT * FROM $table WHERE ";
    $params = [];
    foreach ($where as $key => $value) {
        $params[] = "$key = :$key";
    }
    $sql .= implode(' AND ', $params) . " LIMIT 1";
    $stmt = $pdo->prepare($sql);
    foreach ($where as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function db_update($pdo, $table, $fields, $where) {
    $set = [];
    foreach ($fields as $key => $value) {
        $set[] = "$key = :$key";
    }
    $sql = "UPDATE $table SET " . implode(', ', $set) . " WHERE ";
    $where_clause = [];
    foreach ($where as $key => $value) {
        $where_clause[] = "$key = :where_$key";
    }
    $sql .= implode(' AND ', $where_clause);
    
    $stmt = $pdo->prepare($sql);
    foreach ($fields as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    foreach ($where as $key => $value) {
        $stmt->bindValue(":where_$key", $value);
    }
    return $stmt->execute();
}

function db_delete($pdo, $table, $where) {
    $sql = "DELETE FROM $table WHERE ";
    $params = [];
    foreach ($where as $key => $value) {
        $params[] = "$key = :$key";
    }
    $sql .= implode(' AND ', $params);
    $stmt = $pdo->prepare($sql);
    foreach ($where as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    return $stmt->execute();
}